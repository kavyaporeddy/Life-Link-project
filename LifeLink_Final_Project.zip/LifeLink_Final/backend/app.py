from datetime import datetime, timedelta
from math import radians, sin, cos, asin, sqrt
import os
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from sklearn.ensemble import RandomForestRegressor

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE, 'lifelink.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'LifeLink-change-this-secret-in-production'
db = SQLAlchemy(app)
JWTManager(app)
CORS(app, resources={r'/api/*': {'origins': '*'}})

BLOOD_GROUPS = ['A+','A-','B+','B-','AB+','AB-','O+','O-']
ROLES = ['donor','patient','hospital']
COOLDOWN_DAYS = 180
URGENCY_WEIGHT = {'Critical': 100, 'High': 70, 'Normal': 40}


def now(): return datetime.utcnow()
def iso(v): return v.isoformat() if v else None

def parse_dt(v):
    if not v: return None
    try:
        return datetime.fromisoformat(str(v).replace('Z','+00:00')).replace(tzinfo=None)
    except ValueError:
        return None

def haversine(lat1, lon1, lat2, lon2):
    if None in (lat1, lon1, lat2, lon2): return None
    p1, p2 = radians(float(lat1)), radians(float(lat2))
    dp, dl = radians(float(lat2)-float(lat1)), radians(float(lon2)-float(lon1))
    a = sin(dp/2)**2 + cos(p1)*cos(p2)*sin(dl/2)**2
    return 6371 * 2 * asin(sqrt(a))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=now)

class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(30))
    blood_group = db.Column(db.String(5), nullable=False)
    phone = db.Column(db.String(30))
    email = db.Column(db.String(160))
    address = db.Column(db.String(250))
    city = db.Column(db.String(120))
    pincode = db.Column(db.String(20))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    last_donation_date = db.Column(db.DateTime)
    next_eligible_date = db.Column(db.DateTime)
    available = db.Column(db.Boolean, default=True)
    total_donations = db.Column(db.Integer, default=0)
    consent_contact = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=now)

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(30))
    blood_group = db.Column(db.String(5))
    phone = db.Column(db.String(30))
    email = db.Column(db.String(160))
    address = db.Column(db.String(250))
    city = db.Column(db.String(120))

class Hospital(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)
    hospital_name = db.Column(db.String(180), nullable=False)
    phone = db.Column(db.String(30))
    email = db.Column(db.String(160))
    address = db.Column(db.String(250))
    city = db.Column(db.String(120))
    pincode = db.Column(db.String(20))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)

class BloodRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    requester_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    units = db.Column(db.Integer, default=1)
    hospital_name = db.Column(db.String(180), nullable=False)
    location = db.Column(db.String(150), nullable=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    urgency = db.Column(db.String(20), default='High')
    required_datetime = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    status = db.Column(db.String(20), default='OPEN')
    created_at = db.Column(db.DateTime, default=now)

class Response(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey('blood_request.id'), nullable=False)
    donor_id = db.Column(db.Integer, db.ForeignKey('donor.id'), nullable=False)
    status = db.Column(db.String(20), default='PENDING')
    message = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=now)

class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey('donor.id'), nullable=False)
    request_id = db.Column(db.Integer, db.ForeignKey('blood_request.id'))
    donated_at = db.Column(db.DateTime, default=now)
    units = db.Column(db.Integer, default=1)
    hospital_name = db.Column(db.String(180))
    notes = db.Column(db.String(300))


def user_from_token():
    return db.session.get(User, int(get_jwt_identity()))

def current_profile(u):
    if u.role == 'donor': return donor_json(Donor.query.filter_by(user_id=u.id).first())
    if u.role == 'patient':
        p = Patient.query.filter_by(user_id=u.id).first()
        return {'id': p.id, 'age': p.age, 'gender': p.gender, 'blood_group': p.blood_group, 'phone': p.phone, 'email': p.email, 'address': p.address, 'city': p.city}
    h = Hospital.query.filter_by(user_id=u.id).first()
    return {'id': h.id, 'hospital_name': h.hospital_name, 'phone': h.phone, 'email': h.email, 'address': h.address, 'city': h.city, 'pincode': h.pincode, 'latitude': h.latitude, 'longitude': h.longitude}

def auth_json(u):
    return {'token': create_access_token(identity=str(u.id)), 'user': {'id': u.id, 'name': u.name, 'email': u.email, 'role': u.role, 'phone': u.phone}, 'profile': current_profile(u)}

def valid_bg(bg): return bg in BLOOD_GROUPS

def eligible(d): return d.next_eligible_date is None or d.next_eligible_date <= now()

def donor_json(d, distance=None, score=None):
    u = db.session.get(User, d.user_id)
    return {
        'id': d.id, 'name': u.name if u else '', 'age': d.age, 'gender': d.gender,
        'blood_group': d.blood_group, 'phone': d.phone, 'email': d.email,
        'address': d.address, 'city': d.city, 'pincode': d.pincode,
        'latitude': d.latitude, 'longitude': d.longitude, 'available': bool(d.available),
        'eligible': eligible(d), 'last_donation_date': iso(d.last_donation_date),
        'next_eligible_date': iso(d.next_eligible_date), 'total_donations': d.total_donations or 0,
        'contact_allowed': bool(d.consent_contact),
        'distance_km': round(distance, 2) if distance is not None else None,
        'ai_match_score': round(score, 2) if score is not None else None
    }

def request_json(r):
    return {'id': r.id, 'blood_group': r.blood_group, 'units': r.units, 'hospital_name': r.hospital_name,
            'location': r.location, 'latitude': r.latitude, 'longitude': r.longitude, 'urgency': r.urgency,
            'required_datetime': iso(r.required_datetime), 'notes': r.notes, 'status': r.status,
            'created_at': iso(r.created_at), 'requester_user_id': r.requester_user_id}

@app.get('/api/health')
def health(): return jsonify({'ok': True, 'service': 'LifeLink API'})

@app.post('/api/auth/register')
def register():
    d = request.get_json() or {}
    role = str(d.get('role', 'patient')).lower()
    email = str(d.get('email', '')).strip().lower()
    if role not in ROLES or not d.get('name') or not email or not d.get('password'):
        return jsonify({'error': 'Name, email, password and valid role are required'}), 400
    if User.query.filter_by(email=email).first(): return jsonify({'error': 'Email already registered'}), 409
    if role in ('donor','patient') and d.get('blood_group') and not valid_bg(d.get('blood_group')):
        return jsonify({'error': 'Invalid blood group'}), 400
    if role == 'donor' and not valid_bg(d.get('blood_group')):
        return jsonify({'error': 'Donor blood group is required'}), 400
    u = User(name=str(d['name']).strip(), email=email, password_hash=generate_password_hash(d['password']), role=role, phone=d.get('phone'))
    db.session.add(u); db.session.flush()
    if role == 'donor':
        last = parse_dt(d.get('last_donation_date'))
        db.session.add(Donor(user_id=u.id, age=d.get('age'), gender=d.get('gender'), blood_group=d['blood_group'],
            phone=d.get('phone'), email=email, address=d.get('address'), city=d.get('city'), pincode=d.get('pincode'),
            latitude=d.get('latitude'), longitude=d.get('longitude'), last_donation_date=last,
            next_eligible_date=(last + timedelta(days=COOLDOWN_DAYS)) if last else None,
            available=bool(d.get('available', True)), total_donations=int(d.get('total_donations') or 0),
            consent_contact=bool(d.get('consent_contact', True))))
    elif role == 'patient':
        db.session.add(Patient(user_id=u.id, age=d.get('age'), gender=d.get('gender'), blood_group=d.get('blood_group'),
            phone=d.get('phone'), email=email, address=d.get('address'), city=d.get('city')))
    else:
        db.session.add(Hospital(user_id=u.id, hospital_name=d.get('hospital_name') or d['name'], phone=d.get('phone'),
            email=email, address=d.get('address'), city=d.get('city'), pincode=d.get('pincode'),
            latitude=d.get('latitude'), longitude=d.get('longitude')))
    db.session.commit()
    return jsonify(auth_json(u)), 201

@app.post('/api/auth/login')
def login():
    d = request.get_json() or {}; email = str(d.get('email','')).lower().strip()
    u = User.query.filter_by(email=email).first()
    if not u or not check_password_hash(u.password_hash, d.get('password','')): return jsonify({'error': 'Invalid email or password'}), 401
    return jsonify(auth_json(u))

@app.get('/api/profile')
@jwt_required()
def profile():
    u = user_from_token(); return jsonify({'user': {'id':u.id,'name':u.name,'email':u.email,'role':u.role,'phone':u.phone}, 'profile': current_profile(u)})

@app.put('/api/donor/profile')
@jwt_required()
def update_donor():
    u = user_from_token(); d = Donor.query.filter_by(user_id=u.id).first()
    if not d: return jsonify({'error':'Donor profile not found'}), 404
    x = request.get_json() or {}
    for f in ['age','gender','blood_group','phone','address','city','pincode','latitude','longitude','available','consent_contact','total_donations']:
        if f in x: setattr(d, f, x[f])
    if 'last_donation_date' in x:
        d.last_donation_date = parse_dt(x['last_donation_date'])
        d.next_eligible_date = d.last_donation_date + timedelta(days=COOLDOWN_DAYS) if d.last_donation_date else None
    if not valid_bg(d.blood_group): return jsonify({'error':'Invalid blood group'}), 400
    db.session.commit(); return jsonify(donor_json(d))

@app.post('/api/requests')
@jwt_required()
def create_request():
    u = user_from_token(); d = request.get_json() or {}
    if not valid_bg(d.get('blood_group')): return jsonify({'error':'Valid blood group is required'}), 400
    try: units = int(d.get('units',1)); assert units > 0
    except: return jsonify({'error':'Units must be a positive number'}), 400
    r = BloodRequest(requester_user_id=u.id, blood_group=d['blood_group'], units=units,
        hospital_name=str(d.get('hospital_name','')).strip(), location=str(d.get('location','')).strip(),
        latitude=float(d['latitude']) if d.get('latitude') not in (None,'') else None,
        longitude=float(d['longitude']) if d.get('longitude') not in (None,'') else None,
        urgency=d.get('urgency','High'), required_datetime=parse_dt(d.get('required_datetime')), notes=d.get('notes'))
    if not r.hospital_name or not r.location: return jsonify({'error':'Hospital name and location are required'}), 400
    db.session.add(r); db.session.commit(); return jsonify(request_json(r)), 201

@app.get('/api/requests')
@jwt_required()
def my_requests():
    u = user_from_token()
    rs = BloodRequest.query.filter_by(requester_user_id=u.id).order_by(BloodRequest.created_at.desc()).all()
    return jsonify([request_json(r) for r in rs])

@app.get('/api/donor/requests')
@jwt_required()
def donor_requests():
    u = user_from_token(); d = Donor.query.filter_by(user_id=u.id).first()
    if not d: return jsonify({'error':'Donor account required'}), 403
    rs = BloodRequest.query.filter_by(blood_group=d.blood_group, status='OPEN').order_by(BloodRequest.created_at.desc()).all()
    out=[]
    for r in rs:
        response = Response.query.filter_by(request_id=r.id, donor_id=d.id).first()
        out.append({**request_json(r), 'response_status': response.status if response else 'NOT_RESPONDED'})
    return jsonify(out)

@app.get('/api/requests/<int:rid>/matches')
@jwt_required()
def matches(rid):
    r = db.session.get(BloodRequest, rid)
    if not r: return jsonify({'error':'Request not found'}), 404
    donors = Donor.query.filter_by(blood_group=r.blood_group, available=True).all()
    rows=[]
    # Academic ranker: synthetic training labels make the weighting transparent and reproducible.
    X=[]; y=[]
    for i in range(500):
        bg, dist, avail, donation, city, urg = i%101, (i*7)%101, (i*13)%101, (i*17)%101, i%2, (i//2)%2
        X.append([bg,dist,avail,donation,city,urg]); y.append(.35*bg+.30*dist+.15*avail+.12*donation+.05*city+.03*urg)
    model = RandomForestRegressor(n_estimators=100, random_state=42, min_samples_leaf=3).fit(X,y)
    for d in donors:
        if not eligible(d): continue
        dist = haversine(r.latitude,r.longitude,d.latitude,d.longitude)
        distance_score = 100 if dist is None else max(0, 100 - min(dist,50)*2)
        days = 999 if not d.last_donation_date else max(0,(now()-d.last_donation_date).days)
        donation_score = min(100, 50 + days/2)
        city_match = 1 if r.location.lower().strip() == (d.city or '').lower().strip() else 0
        urgency_score = URGENCY_WEIGHT.get(r.urgency, 70)
        features=[[100, distance_score, 100, donation_score, city_match*100, urgency_score]]
        score=float(model.predict(features)[0])
        # Keep score interpretable and normalized to 0-100.
        score=max(0,min(100,score))
        rows.append(donor_json(d,dist,score))
    rows.sort(key=lambda x: x['ai_match_score'] or 0, reverse=True)
    return jsonify(rows[:50])

@app.post('/api/requests/<int:rid>/respond')
@jwt_required()
def respond(rid):
    u=user_from_token(); d=Donor.query.filter_by(user_id=u.id).first(); r=db.session.get(BloodRequest,rid)
    if not d or not r: return jsonify({'error':'Invalid donor or request'}), 400
    if d.blood_group != r.blood_group or not d.available or not eligible(d): return jsonify({'error':'Donor is not currently eligible/available'}), 400
    x=request.get_json() or {}; status=str(x.get('status','ACCEPTED')).upper()
    if status not in ('ACCEPTED','REJECTED'): return jsonify({'error':'Response must be ACCEPTED or REJECTED'}), 400
    resp=Response.query.filter_by(request_id=rid,donor_id=d.id).first() or Response(request_id=rid,donor_id=d.id)
    resp.status=status; resp.message=x.get('message'); db.session.add(resp)
    if status == 'ACCEPTED': r.status='MATCHED'
    db.session.commit(); return jsonify({'message':status,'response_id':resp.id})

@app.get('/api/requests/<int:rid>/responses')
@jwt_required()
def responses(rid):
    r=db.session.get(BloodRequest,rid)
    if not r: return jsonify({'error':'Request not found'}),404
    out=[]
    for x in Response.query.filter_by(request_id=rid).order_by(Response.created_at.desc()).all():
        d=db.session.get(Donor,x.donor_id)
        out.append({'id':x.id,'status':x.status,'message':x.message,'created_at':iso(x.created_at),'donor':donor_json(d)})
    return jsonify(out)

@app.post('/api/donations')
@jwt_required()
def record_donation():
    u=user_from_token(); d=Donor.query.filter_by(user_id=u.id).first()
    if not d: return jsonify({'error':'Donor account required'}),403
    x=request.get_json() or {}; dt=parse_dt(x.get('donated_at')) or now()
    units=max(1,int(x.get('units',1)))
    d.last_donation_date=dt; d.next_eligible_date=dt+timedelta(days=COOLDOWN_DAYS); d.available=False; d.total_donations=(d.total_donations or 0)+units
    z=Donation(donor_id=d.id,request_id=x.get('request_id'),donated_at=dt,units=units,hospital_name=x.get('hospital_name'),notes=x.get('notes'))
    db.session.add(z); db.session.commit(); return jsonify({'message':'Donation recorded','next_eligible_date':iso(d.next_eligible_date)})

@app.get('/api/donations')
@jwt_required()
def donations():
    u=user_from_token(); d=Donor.query.filter_by(user_id=u.id).first()
    if not d: return jsonify([])
    return jsonify([{'id':x.id,'donated_at':iso(x.donated_at),'units':x.units,'hospital_name':x.hospital_name,'request_id':x.request_id,'notes':x.notes} for x in Donation.query.filter_by(donor_id=d.id).order_by(Donation.donated_at.desc()).all()])

@app.get('/api/forecast')
@jwt_required()
def forecast():
    result={}
    for bg in BLOOD_GROUPS:
        vals=[]
        for offset in range(13,-1,-1):
            start=now()-timedelta(days=offset+1); end=start+timedelta(days=1)
            vals.append(BloodRequest.query.filter(BloodRequest.blood_group==bg,BloodRequest.created_at>=start,BloodRequest.created_at<end).count())
        if sum(vals)==0: pred=0
        else:
            X=np.arange(len(vals)).reshape(-1,1); y=np.array(vals,dtype=float)
            from sklearn.linear_model import LinearRegression
            pred=max(0,round(float(LinearRegression().fit(X,y).predict([[len(vals)]])[0]),2))
        result[bg]={'last_14_days':vals,'predicted_next_day':pred}
    return jsonify(result)

@app.post('/api/seed')
def seed():
    if User.query.first(): return jsonify({'error':'Database already contains data. Delete lifelink.db if you want a fresh demo database.'}), 400
    for i,bg in enumerate(BLOOD_GROUPS):
        u=User(name=f'Demo Donor {bg}',email=f'donor{i+1}@demo.local',password_hash=generate_password_hash('Donor@123'),role='donor',phone=f'90000000{10+i}')
        db.session.add(u); db.session.flush()
        db.session.add(Donor(user_id=u.id,age=21+i,gender=['Female','Male'][i%2],blood_group=bg,phone=u.phone,email=u.email,
            address='Demo Road',city='Tirupati',pincode='517501',latitude=13.6288+(i%3)*.004,longitude=79.4192+(i%4)*.004,
            available=True,total_donations=i%3,consent_contact=True))
    p=User(name='Demo Patient',email='patient@demo.local',password_hash=generate_password_hash('Patient@123'),role='patient',phone='9111111111')
    db.session.add(p); db.session.flush(); db.session.add(Patient(user_id=p.id,age=25,gender='Female',blood_group='O+',phone=p.phone,email=p.email,address='Demo Area',city='Tirupati'))
    h=User(name='Demo Hospital Admin',email='hospital@demo.local',password_hash=generate_password_hash('Hospital@123'),role='hospital',phone='9222222222')
    db.session.add(h); db.session.flush(); db.session.add(Hospital(user_id=h.id,hospital_name='LifeLink Demo Hospital',phone=h.phone,email=h.email,address='Demo Road',city='Tirupati',pincode='517501',latitude=13.6288,longitude=79.4192))
    db.session.commit(); return jsonify({'message':'Demo data created','accounts':{'donor':'donor1@demo.local to donor8@demo.local / Donor@123','patient':'patient@demo.local / Patient@123','hospital':'hospital@demo.local / Hospital@123'}})

with app.app_context(): db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)
