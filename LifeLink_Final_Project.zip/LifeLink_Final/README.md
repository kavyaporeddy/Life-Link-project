# LifeLink: AI-Based Smart Blood Donor Matching Platform

A final-year academic full-stack project using Flask + SQLite + React/Vite.

## Main workflow
1. Donor registers with complete person details, blood group, contact, location and donation history.
2. Patient/hospital creates an emergency request with blood group, units, hospital and location.
3. LifeLink searches the dynamic donor database.
4. Donors who are unavailable or inside the configured 180-day cooldown are excluded.
5. Eligible donors are ranked with a Random Forest academic matching model using matching features.
6. Patient/hospital sees the actual donor's profile, distance when coordinates are available, phone/email when contact consent is enabled, availability, eligibility and AI score.
7. Donor can accept/reject the emergency request.
8. A completed donation can be recorded; the donor is then marked unavailable and the next eligibility date is calculated as 180 days later.
9. Hospital dashboard includes request management and a database-driven 14-day demand forecast.

## Requirements
- Python 3.11+ recommended
- Node.js 18+
- npm

## Windows PowerShell setup
### Terminal 1 - backend
```powershell
cd "C:\path\to\LifeLink_Final\backend"
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```
If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

### Terminal 2 - frontend
```powershell
cd "C:\path\to\LifeLink_Final\frontend"
npm install
npm run dev
```
Open the URL printed by Vite.

## Demo data
After starting the backend, you can create demo accounts by opening:
`http://127.0.0.1:5000/api/health`
Then use a REST client/browser extension to POST to `/api/seed`, or simply register your own accounts through the UI.

Demo accounts if `/api/seed` is called once:
- Patient: `patient@demo.local` / `Patient@123`
- Hospital: `hospital@demo.local` / `Hospital@123`
- Donors: `donor1@demo.local` ... `donor8@demo.local` / `Donor@123`

## Important demo note
The matching engine is an academic prototype. It should not be used to make medical transfusion decisions. Actual donor eligibility and transfusion compatibility must be verified by qualified medical/blood-bank professionals.
